from django.urls import path
from leapadmin import views
urlpatterns = [
    path("leapadmindashboard", views.leapadmindashboard, name="leapadmindashboard"),
]
