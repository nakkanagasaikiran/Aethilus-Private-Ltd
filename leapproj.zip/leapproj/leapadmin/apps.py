from django.apps import AppConfig


class LeapadminConfig(AppConfig):
    name = 'leapadmin'
