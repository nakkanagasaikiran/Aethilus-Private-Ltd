from django.shortcuts import render, redirect
from django.db import connection
from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import json
from datetime import datetime
from leap.models import users

# Main Modules
def interndashboard(request):
    try:
        lcheck = request.session["lvalid"]
    except KeyError:
        return redirect("/leap/notloggedin")
    lvalid         = request.session["lvalid"]
    lmessage       = request.session["lmessage"]
    lusername      = request.session["lusername"]
    lresetpassword = request.session["lresetpassword"]
    lactive        = "Dashboard"
    luserdetails   = {"lvalid": lvalid, "lmessage": lmessage, "lusername": lusername, "lresetpassword": lresetpassword}
    return render(request, "intern/interndashboard.html", {"luserdetails": luserdetails, "lactive": "interndashboard"})

def internschedules(request):
    try:
        lcheck = request.session["lvalid"]
    except KeyError:
        return redirect("/leap/notloggedin")
    lvalid         = request.session["lvalid"]
    lmessage       = request.session["lmessage"]
    lusername      = request.session["lusername"]
    lresetpassword = request.session["lresetpassword"]
    lactive        = "Dashboard"
    luserdetails   = {"lvalid": lvalid, "lmessage": lmessage, "lusername": lusername, "lresetpassword": lresetpassword}
    return render(request, "intern/internschedules.html", {"luserdetails": luserdetails, "lactive": "internschedules"})

def internchat(request):
    try:
        lcheck = request.session["lvalid"]
    except KeyError:
        return redirect("/leap/notloggedin")
    lvalid         = request.session["lvalid"]
    lmessage       = request.session["lmessage"]
    lusername      = request.session["lusername"]
    lresetpassword = request.session["lresetpassword"]
    lactive        = "Dashboard"
    luserdetails   = {"lvalid": lvalid, "lmessage": lmessage, "lusername": lusername, "lresetpassword": lresetpassword}
    return render(request, "/chat/room.html", {"luserdetails": luserdetails, "lactive": "internchat"})
