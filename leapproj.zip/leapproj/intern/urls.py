from django.urls import path
from intern import views
urlpatterns = [
    # URLs for Modules
    path("interndashboard/", views.interndashboard, name="interndashboard"),
    path("internschedules/", views.internschedules, name="internschedules"),
    path("internchat/", views.internchat, name="internchat"),
]
