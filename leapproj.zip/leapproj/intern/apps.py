from django.apps import AppConfig


class InternConfig(AppConfig):
    name = 'intern'
