from django.urls import path, include
from django.views.generic import RedirectView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
path("leap/", include("leap.urls")),
path("intern/", include("intern.urls")),
path("leapadmin/", include("leapadmin.urls")),
path('chat/', include('chat.urls')),
path("", RedirectView.as_view(url="/leap/", permanent=True)),
]
