from django.db import models
from django.utils import timezone
from datetime import datetime

class users(models.Model):
    emailid        = models.CharField(max_length=120, unique=True)
    password       = models.CharField(max_length=300, default="")
    username       = models.CharField(max_length=60,  default="")
    mobile         = models.CharField(max_length=60,  default="")
    lastlogin      = models.DateTimeField(null=True, default=timezone.now)
    logedin        = models.CharField(null=True, max_length=3, default="")
    logins         = models.IntegerField(null=True, default=0)
    passwordresets = models.IntegerField(null=True, default=0)
    failedattempts = models.IntegerField(null=True, default=0)
    resetpassword  = models.CharField(max_length=3, null=True, default=0)
    secretkey      = models.CharField(max_length=15, null=True, default=0)
    status         = models.CharField(max_length=30, default="")
    startdate      = models.DateField(default=datetime.today)
    enddate        = models.DateField(default=datetime.today)
    createdby      = models.CharField(max_length=120, default="")
    createdon      = models.DateTimeField(default=timezone.now)
    updatedby      = models.CharField(max_length=120, default="")
    updatedon      = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.emailid + " " + self.username
    class Meta:
        indexes = [
            models.Index(name="leapusers_n1", fields=["emailid", "status"])
        ]
class sitevisitors(models.Model):
    visitorurl = models.CharField(max_length=3000)
    visitdate  = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.visitorurl
    class Meta:
        indexes = [
            models.Index(name="sitevisitors_n1", fields=["visitorurl"])
        ]
class loginhistory(models.Model):
    emailid       = models.CharField(max_length=120)
    logindate     = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.emailid
    # class Meta:
        indexes = [
            models.Index(name="loginhistory_n1", fields=["emailid"]),
        ]
class downtime(models.Model):
    emailid     = models.CharField(max_length=120, null=True)
    phonenumber = models.CharField(max_length=120, null=True)
    maintenance = models.CharField(max_length=3000, null=True)
    remarks     = models.CharField(max_length=3000, null=True)
    startdate   = models.DateTimeField(default=timezone.now)
    enddate     = models.DateTimeField(default=timezone.now)
    status      = models.CharField(max_length=30, default="")
    createdby   = models.CharField(max_length=120, default="")
    createdon   = models.DateTimeField(default=timezone.now)
    updatedby   = models.CharField(max_length=120, default="")
    updatedon   = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.emailid
    class Meta:
        indexes = [
            models.Index(name="downtime_n1", fields=["status", "startdate"]),
        ]
