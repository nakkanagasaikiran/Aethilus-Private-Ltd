from django.urls import path
from leap import views
urlpatterns = [
    path("", views.leap, name="leap"),
    path("login/", views.login, name="login"),
    path("register/", views.register, name="register"),
    path("forgotpassword/", views.forgotpassword, name="forgotpassword"),
    path("resetpassword/", views.resetpassword, name="resetpassword"),
    path("isemailavailable/", views.isemailavailable, name="isemailavailable"),
    path("userdashboard/", views.userdashboard, name="userdashboard"),
]
