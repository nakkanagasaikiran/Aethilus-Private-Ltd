function leapajaxcall(pdata, purl, ptpl, pplh, pasys) {
  $.ajax({
    async: pasys,
    type: "GET",
    url: purl,
    data: pdata,
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function(ldata) {
      console.log(pplh + " - " + pasys);
      if (ptpl !== null) {
        var ltemplate = $.templates(ptpl);
        var lldata    = ltemplate.render(ldata);
        $(pplh).html(lldata);
      }
      // Login
      if (pplh === "isemailavailable") {
        if (ldata.lvalid === "Yes") {
          toastr.success(ldata.lmessage);
        }
        else {
          alert(ldata.lvalid);
          toastr.error(ldata.lmessage);
        }
      }
    }
  });
}
