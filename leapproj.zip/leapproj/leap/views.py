from django.db import connection, ProgrammingError, InternalError
from django.utils import timezone
from django.shortcuts import render, redirect
from django.utils.crypto import get_random_string
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives
from django.core.files.storage import FileSystemStorage
from datetime import datetime
from django.http import HttpResponse
from django.conf import settings
from ipware import get_client_ip
import socket
import json
from leap.models import downtime, sitevisitors, users

def leap(request):
    lip = get_client_ip(request)
    lip = lip[0]
    lhostname = socket.gethostname()
    lsitevisitors = sitevisitors(visitorurl=lhostname + " - " +lip, visitdate=timezone.now())
    lsitevisitors.save()
    try:
        ldowntime = downtime.objects.only("id", "emailid", "phonenumber", "maintenance", "remarks", "startdate", "enddate", "status", "createdby", "createdon", "updatedby", "updatedon").get(status="Active")
    except downtime.DoesNotExist:
        return render(request, "leap/index.html")
    return render(request, "leap/downtime.html", {"ldowntime": ldowntime})
def login(request):
    lip = get_client_ip(request)
    lip = lip[0]
    lhostname = socket.gethostname()
    lsitevisitors = sitevisitors(visitorurl=lhostname + " - " +lip, visitdate=timezone.now())
    lsitevisitors.save()
    lmessage, lvalid, aa = "", "", ""
    try:
        ldowntime = downtime.objects.only("id", "emailid", "phonenumber", "maintenance", "remarks", "startdate", "enddate", "status", "createdby", "createdon", "updatedby", "updatedon").get(status="Active")
    except downtime.DoesNotExist:
        if request.method == "POST":
            lmessage = ""
            lvalid = ""
            ccheckdb = connection.cursor()
            try:
                ccheckdb.execute("BEGIN")
                ccheckdb.callproc("leap_login_validate", [request.POST.get("emailid"), request.POST.get("password1")])
                results = ccheckdb.fetchone()
            except ProgrammingError as e:
                lerror = e.__cause__
                lmessage = "We apologise you ran into this technical issue with E L A H. The Admin has been notified and a ticket has been logged under your name so we can update you with more details on the issue and fix. You should also be receiving an email at " +request.POST.get("emailid")
                return render(request, "leap/downtime.html", {"lerror": lerror, "lmessage": lmessage})
            except InternalError as e:
                lerror = e.__cause__
                lmessage = "We apologise you ran into this technical issue with E L A H. The Admin has been notified and a ticket has been logged under your name so we can update you with more details on the issue and fix. You should also be receiving an email at " +request.POST.get("emailid")
                return render(request, "leap/downtime.html", {"lerror": lerror, "lmessage": lmessage})
            finally:
                ccheckdb.close()
            lvalid,         request.session["lvalid"]         = results[0],  results[0]
            lmessage,       request.session["lmessage"]       = results[1],  results[1]
            lusername,      request.session["lusername"]      = results[2],  results[2]
            lresetpassword, request.session["lresetpassword"] = results[3],  results[3]
            luserdetails = {"lvalid": lvalid, "lmessage": lmessage, "lusername": lusername, "lresetpassword": lresetpassword}
            if lvalid == "Yes":
                return redirect("/intern/interndashboard", {})
            elif lvalid == "No":
                return render(request, "leap/login.html", { "lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
            elif lvalid == "Locked":
                return render(request, "leap/login.html", { "lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
            elif lvalid == "Reset":
                return render(request, "leap/login.html", { "lmessage": lmessage, "lvalid": lvalid })
        return render(request, "leap/login.html", { "lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
    return render(request, "leap/downtime.html", {"lleapdowntime": lleapdowntime})
def register(request):
    lmessage, lvalid = "", ""
    try:
        ldowntime = downtime.objects.only("id", "emailid", "phonenumber", "maintenance", "remarks", "startdate", "enddate", "status", "createdby", "createdon", "updatedby", "updatedon").get(status="Active")
    except downtime.DoesNotExist:
        if request.method == "POST":
            lmessage = ""
            lvalid = ""
            lemailid   = request.POST.get("emailid")
            lpassword  = request.POST.get("password1")
            lusername  = request.POST.get("name")
            lmobile    = request.POST.get("mobile")
            lcreatedby = request.POST.get("emailid")

            ccheckdb = connection.cursor()
            try:
                ccheckdb.execute("BEGIN")
                ccheckdb.callproc("leap_user_register", [lemailid, lpassword, lusername, lmobile, lcreatedby])
                lsaved = ccheckdb.fetchone()
                ccheckdb.execute("COMMIT")
            except ProgrammingError as e:
                lerror = e.__cause__
                lmessage = "We apologise you ran into this technical issue with E L A H. The Admin has been notified and a ticket has been logged under your name so we can update you with more details on the issue and fix. You should also be receiving an email at " +request.POST.get("emailid")
                return render(request, "leap/downtime.html", {"lerror": lerror, "lmessage": lmessage})
            except InternalError as e:
                lerror = e.__cause__
                lmessage = "We apologise you ran into this technical issue with E L A H. The Admin has been notified and a ticket has been logged under your name so we can update you with more details on the issue and fix. You should also be receiving an email at " +request.POST.get("emailid")
                return render(request, "leap/downtime.html", {"lerror": lerror, "lmessage": lmessage})
            finally:
                ccheckdb.close()
                lvalid   = lsaved[0]
                lmessage = lsaved[1]
            return render(request, "leap/register.html", { "lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
        return render(request, "leap/register.html", { "lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
    return render(request, "leap/downtime.html", {"ldowntime": ldowntime})
def forgotpassword(request):
    lvalid = ""
    lmessage = ""
    try:
        ldowntime = downtime.objects.only("id", "emailid", "phonenumber", "maintenance", "remarks", "startdate", "enddate", "status", "createdby", "createdon", "updatedby", "updatedon").get(status="Active")
    except downtime.DoesNotExist:
        if request.method == "POST":
            lemailid = request.POST.get("emailid")
            print(lemailid)
            lsecretkey = get_random_string(length=6)
            cCheckDb = connection.cursor()
            try:
                cCheckDb.execute("BEGIN")
                cCheckDb.callproc("leap_forgot_password", [request.POST.get("emailid"), lsecretkey])
                results = cCheckDb.fetchone()
                cCheckDb.execute("COMMIT")
            except ProgrammingError as e:
                lerror = e.__cause__
                lmessage = "We apologise you ran into this techical issue with E L A H. The Admin has been notified and a ticket has been logged under your name so we can update you with more details on the issue and fix. You should also be receiving an email at " +request.POST.get("emailid")
                return render(request, "leap/downtime.html", {"lerror": lerror, "lmessage": lmessage})
            except InternalError as e:
                lerror = e.__cause__
                lmessage = "We apologise you ran into this techical issue with E L A H. The Admin has been notified and a ticket has been logged under your name so we can update you with more details on the issue and fix. You should also be receiving an email at " +request.POST.get("emailid")
                return render(request, "leap/downtime.html", {"lerror": lerror, "lmessage": lmessage})
            finally:
                cCheckDb.close()
            lvalid = results[0]
            lmessage = results[1]
            if lvalid == "Yes":
                subject = "LEAP Reset Password Request"
                to = ['"'+lemailid+'"']
                to = [lemailid]
                from_email = "LEAP Admin<nagasaikiran@aethilus.com>"
                message = render_to_string("leap/emailalert.html", {"lsecretkey": lsecretkey}).strip()
                msg = EmailMultiAlternatives(subject, message, to=to, from_email=from_email)
                msg.content_subtype = "html"
                msg.send()
                return render(request, "leap/forgotpassword.html", {"lmessage": lmessage, "lvalid": lvalid})
            elif lvalid == "No":
                return render(request, "leap/forgotpassword.html", {"lmessage": lmessage, "lvalid": lvalid})
        return render(request, "leap/forgotpassword.html", {"lmessage": lmessage, "lvalid": lvalid})
    return render(request, "leap/downtime.html", {"ldowntime": ldowntime})
def resetpassword(request):
    lmessage = ""
    lvalid = "Yes"
    try:
        ldowntime = downtime.objects.only("id", "emailid", "phonenumber", "maintenance", "remarks", "startdate", "enddate", "status", "createdby", "createdon", "updatedby", "updatedon").get(status="Active")
    except downtime.DoesNotExist:
        if request.method == "POST":
            lemailid         = request.POST.get("emailid")
            lsecretkey       = request.POST.get("secretkey")
            lpassword1       = request.POST.get("password1")
            lpassword        = request.POST.get("password")
            lreenterpassword = request.POST.get("reenterpassword")
            try:
                tfetchdata = users.objects.get(emailid=lemailid)
            except users.DoesNotExist:
                lmessage = "LEAP-R01 - " + lemailid + " is not a valid Email ID. Re-enter the correct Email ID. Contact your Administrator to check if your account has been setup."
                lvalid = "No"
                return render(request, "leap/resetpassword.html",  {"lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
            if lvalid == "Yes":
                if lpassword != lreenterpassword:
                    lmessage = "LEAP-R02 - Your New Password and Confirmation Password Do not Match."
                    lvalid = "No"
                    return render(request, "leap/resetpassword.html",  {"lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
            if lvalid == "Yes":
                if tfetchdata.secretkey == "":
                    lmessage = "LEAP-R04 - There is no valid Secret Key available to reset your password click on Forgot Password to create a new Secret Key."
                    lvalid = "No"
                    return render(request, "leap/resetpassword.html",  {"lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
            if lvalid == "Yes":
                if lsecretkey != tfetchdata.secretkey:
                    lmessage = "LEAP - R03 - The Secret Key You Entered Is Invalid. Re-enter the right Secret Key or click on Forgot Password Button to get a new Secret Key."
                    lvalid = "No"
                    return render(request, "leap/resetpassword.html",  {"lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
            if lvalid == "Yes":
                ccheckdb = connection.cursor()
                try:
                    ccheckdb.execute("BEGIN")
                    ccheckdb.callproc("leap_reset_password", [lemailid, lpassword1])
                    lsaved = ccheckdb.fetchone()
                    ccheckdb.execute("COMMIT")
                finally:
                    ccheckdb.close()
                    lvalid   = lsaved[0]
                    lmessage = lsaved[1]
                if lvalid == "Yes":
                    return render(request, "leap/resetpassword.html", {"lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
        return render(request, "leap/resetpassword.html",  {"lmessage": lmessage, "lvalid": lvalid, "lsalt": settings.SECRET_KEY})
    return render(request, "leap/downtime.html", {"ldowntime": ldowntime})
def isemailavailable(request):
    lemailid = request.GET.get("pemailid")

    ccheckdb = connection.cursor()
    try:
        ccheckdb.execute("BEGIN")
        ccheckdb.callproc("leap_isemailavailable", [lemailid])
        lsaved = ccheckdb.fetchone()
        ccheckdb.execute("COMMIT")
    finally:
        ccheckdb.close()
        lvalid   = lsaved[0]
        lmessage = lsaved[1]
    return HttpResponse(json.dumps({"lvalid": lvalid, "lmessage": lmessage}))
def userdashboard(request):
    try:
        ldowntime = downtime.objects.only("id", "emailid", "phonenumber", "maintenance", "remarks", "startdate", "enddate", "status", "createdby", "createdon", "updatedby", "updatedon").get(status="Active")
    except downtime.DoesNotExist:
        return render(request, "leap/userdashboard.html")
    return render(request, "leap/downtime.html", {"ldowntime": ldowntime})
