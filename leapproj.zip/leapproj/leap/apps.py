from django.apps import AppConfig


class LeapConfig(AppConfig):
    name = 'leap'
